# SolarRoof

Is your roof green enough?!

### Abstract

Traditionally, when a customer wants to install solar panels on their house, the company would send out a team to measure the roof dimension and cutomized/find the solar panels that will fit. This back-and-forth takes a lot of time and increases the risk of workers' injury. This project implemented a variation of convolutional neural network, called U-net, to segment individual's roof using aerial/satelite images.

Due to the limited labeled roof images, I implemented a U-net model on segment building with public aerial images (https://project.inria.fr/aerialimagelabeling/). Roof boundary is very close to the building boundray from the top-view. Few modifications will be needed to improve the accuray of roof boundary. 

# Installation

The file, requirement.txt, contains the python package dependencies for this project. Installation can be performed via 


pip install -r requirement.txt

# Input images

Please find the public pre-processed data set for training this model in Data folder. 

# Preprocessing

Input data were RGB images and in PNG format. 
The public data set is high resolution (5000x5000) but too big to start with to train the MVP model. Therefore, I sliced the originial image evenly into 625 smaller images, resulting 625 (200 * 200) images. The label set was preprocessed the same as training set. 


# Model
![Unet](https://github.com/julia78118/SolarRoof/blob/master/Unet.jpg)

The U-net model code base was inspired by https://github.com/zhixuhao/unet but heavily modified for this project.

# Inference

Test images can also be found in the Data folder. 
Perform via command line

# Postprocessing

The boundary will be shown on the original input image

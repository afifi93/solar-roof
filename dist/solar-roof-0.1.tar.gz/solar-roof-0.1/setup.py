from distutils.core import setup

setup(
    name='solar-roof',
    version='0.1',
    packages=['solar_roof', ],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
